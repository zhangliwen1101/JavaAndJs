package com.jack.javajs;

import java.util.Set;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/*
 * js��java�ķ�����������java��ֵ
 */
public class MyWebActivity extends Activity {
	private WebView webView;

	@SuppressLint("SetJavaScriptEnabled")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_web);
		webView = (WebView) findViewById(R.id.webview);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webView.getSettings().setDatabaseEnabled(true);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setUseWideViewPort(true);
		webView.getSettings().setBuiltInZoomControls(false);// Ϊ25%����С���ŵȼ�
		webView.getSettings().setLoadWithOverviewMode(true);
		webView.setVerticalScrollBarEnabled(false);// ������
		webView.addJavascriptInterface(new getHtmlObject(), "JavaJs");
		webView.setInitialScale(100);
		webView.getSettings().setDomStorageEnabled(true);
		webView.setWebViewClient(new WebViewClient() {

			@SuppressLint("NewApi") @Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("��ȡURL:" + url);
				Uri url11 = Uri.parse(url);
				Set<String> names = url11.getQueryParameterNames();
				for (String name : names) {
					if (name.equals("type")) {
						
					}
				}
				return super.shouldOverrideUrlLoading(view, url);
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
			}

			@Override
			public void onReceivedSslError(WebView view,
					SslErrorHandler handler, SslError error) {
				super.onReceivedSslError(view, handler, error);
			}
		});
		// �̳�WebChromeClient�� ��js������ʱ����д���
		webView.setWebChromeClient(new MyWebChromeClient());
		// webView.loadUrl("file:///android_asset/Test.html");
		webView.loadUrl("http://www.baidu.com");
	}

	/**
	 * �̳�WebChromeClient�� ��js������ʱ����д���
	 * 
	 */
	final class MyWebChromeClient extends WebChromeClient {
		/**
		 * ����alert������
		 */
		@Override
		public boolean onJsAlert(WebView view, String url, String message,
				JsResult result) {
			// message:alert�е�����
			System.out.println("message:" + message + "   url:" + url
					+ "    result:" + result);
			result.confirm();
			return true;
		}

		/**
		 * ����confirm������
		 */
		@Override
		public boolean onJsConfirm(WebView view, String url, String message,
				JsResult result) {
			// message:window.confirm�е�����
			System.out.println("message:" + message);
			result.confirm();
			return super.onJsConfirm(view, url, message, result);
		}
	}

	public class getHtmlObject {
		@JavascriptInterface
		public void JavaAndJs(final String str) {
			Toast.makeText(MyWebActivity.this, str, 1000).show();
		}
	}
}
