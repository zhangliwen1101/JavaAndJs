package com.jack.javajs;

import java.io.FileReader;

import javax.script.Bindings;
import javax.script.Invocable;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button button, button1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		button = (Button) findViewById(R.id.button);
		button1 = (Button) findViewById(R.id.button1);
		button.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, MyWebActivity.class);
				startActivity(intent);
			}
		});
		button1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				//�ᱨ��
				ScriptEngineManager manager = new ScriptEngineManager();
				ScriptEngine engine = manager.getEngineByName("javascript");
				Bindings bind = engine.createBindings();  
		        bind.put("factor", 2);    //�����һ��factor��ֵΪ2.
		        engine.setBindings(bind,ScriptContext.ENGINE_SCOPE);  
				String jsFileName = "file:///android_asset/JavaToJs.js"; // ��ȡjs�ļ�
				FileReader reader;
				try {
					reader = new FileReader(jsFileName);
					engine.eval(reader);
					if (engine instanceof Invocable) {
						Invocable invoke = (Invocable) engine; //
						// ����merge��������������������
						Double c = (Double) invoke
								.invokeFunction("cal", 2, 3);
						System.out.println("c = " + c);
					}
					reader.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});

	}
}
